# DueWise Test Record

Write only results you actually saw. If a check fails, add it to the Bug log, fix it, and test again.

## Test environment

| Item | Value |
| --- | --- |
| App version / commit | |
| Device | |
| Android version | |
| Testers | |
| Test dates | |

Result codes: PASS = worked as expected, FAIL = did not (see Bug log).

## Phase 1: Stability

| # | Check | Steps | Expected | Result | Tester | Date |
| --- | --- | --- | --- | --- | --- | --- |
| 1.1 | Forward navigation | Today > tap a task | Its Task details opens | | | |
| 1.2 | Back stack | Today > task > assignment name > a task > Back repeatedly | Goes back one screen at a time to Today, then app closes | | | |
| 1.3 | Rapid tapping | Triple-tap a task card, + Add assignment, Edit task, bell, an assignment card | Only one screen opens | | | |
| 1.4 | Rapid back | Triple-tap the back arrow on Edit task | Goes back one screen only | | | |
| 1.5 | No automatic navigation | Open the app and wait 10 seconds | No screen opens by itself | | | |
| 1.6 | Arguments | Open 3 different tasks; plan "Math Quiz / Ch. 3" | Each shows its own data; title shows correctly on step 2 | | | |
| 1.7 | State consistent | Complete Find sources on Upcoming | Shows done on Today, Completed and Task details | | | |
| 1.8 | Rapid toggling | Tap a task's circle 6 times quickly | Ends in a correct state, no crash | | | |

## Phase 2: Code review

| # | Check | How checked | Result | Tester | Date |
| --- | --- | --- | --- | --- | --- |
| 2.1 | No unused code | Code > Inspect Code, "Unused declaration" | | | |
| 2.2 | No debug logs / commented-out code | Find in Files: Log. , println | | | |
| 2.3 | Routes in one place | Find in Files: "task_details | | | |
| 2.4 | Navigation in one place | All navigate/popBackStack calls are in DueWiseNavHost.kt | | | |

## Phase 3: Visual alignment with the prototype

| # | Screen | Matches Figma layout, spacing, text sizes | Result | Notes | Tester | Date |
| --- | --- | --- | --- | --- | --- | --- |
| 3.1 | Today | | | | | |
| 3.2 | Upcoming / Completed | | | | | |
| 3.3 | Task details / Edit / Delete | | | | | |
| 3.4 | New assignment / Add smaller tasks | | | | | |
| 3.5 | Notifications / Settings / Login | | | | | |

## Phase 4: Full walkthrough

| # | Step | Expected | Result | Tester | Date |
| --- | --- | --- | --- | --- | --- |
| 4.1 | Today > + Add assignment > fill step 1 > Continue | Step 2 opens with the title | | | |
| 4.2 | Add 2 tasks > Save plan | Both appear in Upcoming in date order | | | |
| 4.3 | Open a new task > Edit date > Save | Order updates in Upcoming | | | |
| 4.4 | Mark completed > Completed tab > undo | Moves to Completed and back | | | |
| 4.5 | Delete the task, then its assignment | Both removed, returns to Today | | | |
| 4.6 | Back until the app closes | One screen at a time | | | |
| 4.7 | Repeat 4.1-4.6 quickly | Same behavior | | | |

## Phase 5: Feedback fixes

| # | Check | Steps | Expected | Result | Tester | Date |
| --- | --- | --- | --- | --- | --- | --- |
| 5.1 | Overdue shown | Look at a pending task dated before today | Red date + OVERDUE; Task details status "Overdue" | | | |
| 5.2 | Overdue clears | Complete an overdue task | Red date and label disappear | | | |
| 5.3 | Assignments list | Tap Assignments tab | Every assignment listed, nearest deadline first | | | |
| 5.4 | Assignment not lost | Delete all tasks of one assignment | It still shows, with "No tasks yet" | | | |
| 5.5 | Add task later | Assignment details > + Add task > Save | Task appears in the assignment, Upcoming, Assignments | | | |
| 5.6 | Add task validation | Empty name; date after deadline | Save disabled / red message | | | |
| 5.7 | Rotation: Edit task | Type, rotate | Typed values stay | | | |
| 5.8 | Rotation: Add smaller tasks | Add 2 tasks, type a 3rd, rotate | All stay | | | |
| 5.9 | Rotation: forms and dialogs | Step 1, Add task, Login, date picker, Log out dialog | All keep their input / stay open | | | |

## Bug log

| # | Found in check | What happened | Fix | Fixed by | Commit |
| --- | --- | --- | --- | --- | --- |
| B1 | | | | | |
