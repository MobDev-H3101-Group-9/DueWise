package com.duewise.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.duewise.app.data.Assignment
import com.duewise.app.data.Task
import com.duewise.app.ui.components.DueWiseCard
import com.duewise.app.ui.components.EmptyState
import com.duewise.app.ui.components.OutlinedActionButton
import com.duewise.app.ui.components.ScreenHeader
import com.duewise.app.ui.components.ScrollScreen
import com.duewise.app.ui.components.SectionLabel
import com.duewise.app.ui.components.TaskCard
import com.duewise.app.ui.theme.AccentBlue
import com.duewise.app.ui.theme.CardBorder
import com.duewise.app.ui.theme.DangerRed
import com.duewise.app.ui.theme.TextPrimary
import com.duewise.app.ui.theme.TextSecondary
import com.duewise.app.util.toDisplayDate

// One assignment and all of its tasks.
@Composable
fun AssignmentDetailsScreen(
    assignment: Assignment,
    tasks: List<Task>,
    onBack: () -> Unit,
    onOpenTask: (Int) -> Unit,
    onToggleTask: (Int) -> Unit,
    onAddTask: () -> Unit,
    onDeleteAssignment: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenHeader(title = "Assignment details", onBack = onBack) }

        // Summary card: title, subject, final deadline
        item {
            DueWiseCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = assignment.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Text(text = assignment.subject, style = MaterialTheme.typography.bodyLarge, color = TextSecondary)
                    HorizontalDivider(color = CardBorder, modifier = Modifier.padding(vertical = 12.dp))
                    Text(
                        text = "Final deadline: ${assignment.deadline.toDisplayDate()}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextPrimary
                    )
                }
            }
        }

        item { SectionLabel("Tasks") }

        if (tasks.isEmpty()) {
            item { EmptyState("This assignment has no tasks.") }
        } else {
            items(tasks) { task ->
                TaskCard(
                    task = task,
                    assignmentTitle = null,
                    onToggleCompleted = { onToggleTask(task.id) },
                    onOpen = { onOpenTask(task.id) }
                )
            }
        }

        item {
            OutlinedActionButton(text = "+ Add task", onClick = onAddTask, textColor = AccentBlue)
        }

        item {
            OutlinedActionButton(
                text = "Delete assignment",
                onClick = onDeleteAssignment,
                textColor = DangerRed,
                centered = true
            )
        }
    }
}

// Asks before deleting an assignment and all its tasks. Cancel changes nothing.
@Composable
fun DeleteAssignmentScreen(
    assignment: Assignment,
    taskCount: Int,
    onCancel: () -> Unit,
    onConfirmDelete: () -> Unit
) {
    ScrollScreen {
        ScreenHeader(title = "Delete assignment", onBack = onCancel)
        Text(text = "Delete this assignment?", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
        Text(text = assignment.title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        Text(
            text = "The assignment and its $taskCount task(s) will be removed from your lists.",
            style = MaterialTheme.typography.bodyLarge,
            color = TextSecondary
        )
        OutlinedActionButton(text = "Cancel — keep assignment", onClick = onCancel)
        OutlinedActionButton(text = "Delete assignment", onClick = onConfirmDelete, textColor = DangerRed)
    }
}
